# C# Fundamental Assignemnt 1

Practice fundamental C#

## Requirements

Navigate to file Program.cs and provide logics for following function:

1. Complete function `toTitleCase` to convert an English string to title case, not using any library. For example, string: “this is a text” => “This Is A Text”
2. Complete function `matrixMultiply` to multiply 2 matrices of integer numbers
