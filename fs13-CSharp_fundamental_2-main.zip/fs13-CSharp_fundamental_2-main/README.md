# C# Fundamental Assignment 2

Please check for all the challenges in `Assignment/Program.cs``

## Run the program `dotnet run --project Assignment`
